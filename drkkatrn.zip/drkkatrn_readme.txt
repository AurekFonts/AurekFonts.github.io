Dark Katarn
Macintosh & Windows TrueType Font
Created by ErikStormtrooper.com

--------------------------------------------------

FONT INFORMATION

This font re-creates a forgotten Star Wars alphabet that appeared in the classic LucasArts games X-Wing, TIE-Fighter, and Dark Forces. Those who've played these games will most likely remember it from Dark Forces, where it appeared on crates and keys used for combination locks. 

This font includes all letters, numbers, and common punctuation marks. Uppercase letters are larger versions of lowercase letters. Also, kerning has been enabled for this font. 

--------------------------------------------------

ACCURACY OF THIS FONT

There are only 12 "canon" letters in this alphabet, which appear in X-Wing. In my font, these letters are represented as: A, C, D, E, H, I, L, N, O, R, S, T. These 12 letters are the most frequent in English. I chose them so written passages would look as canon as possible. Most of the other letters in this font were inspired by barely-legible characters seen in Dark Forces.

Numbers 1-6 are canon based on numbers seen in Dark Forces. I created numbers 7-9 and 0 in the same style.

--------------------------------------------------

LEGAL MUMBO JUMBO

This font is not officially licensed and is not intended to infringe on 
any copyright. This font is freeware; it may be distributed freely, but 
PLEASE distribute all files included in the ZIP archive. This font is
NOT to be sold or used for financial gain. Help keep it free and
available!