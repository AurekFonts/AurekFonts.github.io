Auraboo is an Aurebesh font designed by Nick Tierce.
https://www.NickTierce.com/

It is based on a font seen briefly in Star Wars: Episode I, when R2-D2 tells Anakin to "turn the ship around and go back homie right awayl [sic]".

Punctuation was based on a softened version of standard Aurebesh punctuation.
Missing letters were designed with input from AurekFonts.
https://AurekFonts.github.io

License:
This font is Free for All Personal and Commercial Uses.