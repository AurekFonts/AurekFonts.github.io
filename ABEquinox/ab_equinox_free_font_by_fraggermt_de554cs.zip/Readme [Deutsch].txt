AB EQUINOX

eine Aurebesh-Schriftart von Fragger MT, frei nutzbar von allen für alles.



__________




AB Equinox ist eine älter-groteske Großbuchstaben-Schriftart für das Aurebesh-Schriftsystem. Die schwergewichtigen Lettern sind von lantillianischer Schlichtheit geprägt und nutzen uniforme Winkel sowie selektive Strichkreuzungen, um eine solide Dekorativ-Schriftart für Schilder, Überschriften und Schriftmarken zu konstruieren.




Inhalt:

- AB Equinox umfasst 26 Lettern, 8 Digraphen, 10 Numerale, 2 Währungssymbole und 23 Satzzeichen. 




Wichtige Hinweise zur Fehlerbehebung:

- AB Equinox ist für englische Tastatureingaben optimiert. Dies ist unter anderem für Anführungszeichen zu berücksichtigen, die bei deutschen Eingaben falsch angezeigt werden.

- Wenn zwischen Buchstaben (wie dem X und dem V beispielsweise) unüblich große Lücken entstehen, unterstützt das genutzte Schreibprogramm entweder keine Unterschneidungen oder hat Unterschneidungen deaktiviert. Es sollte ein Schreibprogramm genutzt werden, das Unterschneidungen unterstützt.

- AB Equinox nutzt OpenType-Standardligaturen, um Aurebesh-Digraphen zu erzeugen, die zwei Buchstaben (wie TH oder SH beispielsweise) zu einem zusammenfassen. Funktioniert dies nicht, unterstützt das genutzte Schreibprogramm entweder keine Ligaturen oder hat Ligaturen deaktiviert. Es sollte ein Schreibprogramm genutzt werden, das Ligaturen unterstützt.




Voraussetzungen:

- Um die Schriftart zu installieren, wird ein modernes Endgerät benötigt, welches das OpenType-Format unterstützt.




Nutzungsregeln:

- AB Equinox ist und bleibt gratis.

- AB Equinox darf in jedem kommerziellen oder persönlichem Projekt genutzt werden.

- AB Equinox darf modifiziert werden.

- AB Equinox darf auf anderen Webseiten zum Download angeboten werden.

- Ich kann niemanden, der AB Equinox nutzen möchte, dazu zwingen, meinen Namen (Fragger MT) oder den Namen der Schriftart zu nennen. Trotzdem würde ich mich darüber freuen. ;-)

- TL;DR: Es gibt keine Regeln. Viel Spaß!