AB EQUINOX

an Aurebesh typeface by Fragger MT, free to use by anyone for anything.



__________




AB Equinox is a neo-grotesque single-case typeface for the Aurebesh writing system. Its heavyweight letters are styled with Lantillian simplicity in mind, utilizing uniform angles and selective intersections to construct a solid display typeface intended for signs, headlines and brands.




Content:

- AB Equinox includes 26 letters, 8 digraphs, 10 numerals, 2 currency symbols and 23 punctuation symbols.




Important notes and troubleshooting:

- AB Equinox is optimized for English keyboard input. Using the font with other languages can result in occasional display errors, especially when typing quotation marks.

- If you notice unusually large gaps between letters (V and X for example), your software used to write either does not support kerning or has kerning disabled. You need to switch to a software capable of displaying kerning or simply activate kerning.

- AB Equinox uses OpenType standard ligatures to display Aurebesh digraphs which fuse two letters into a single one (TH or SH for example). If this does not work, your software used to write either does not support ligatures or has ligatures disabled. You need to switch to a software capable of displaying ligatures or simply activate ligatures.




Requirements:

- To install this font a modern device and software that supports the OpenType format is required.




Rules for using this typeface:

- AB Equinox is forever free of charge.

- AB Equinox may be used in any commercial or personal project.

- AB Equinox may be modified.

- AB Equinox may be redistributed on other websites.

- I can force no one to mention my name (Fragger MT) or the name of the typeface when used. I would appreciate it, though. ;-)

- TL;DR: There are no rules. Have fun!