ENGLI-BESH
Macintosh & Windows TrueType Font
Created by ErikStormtrooper.com

--------------------------------------------------

FONT INFORMATION

This font is an English version of the Star Wars alphabet known 
as "Aurebesh". After doing research for my "Galactic Basic" font,
I noticed several similarities between the English alphabet and
Aurebesh. I figured this font would be a good way to spice up
good ole English with a touch of Star Wars.

This font includes all letters, numbers, and common punctuation 
marks. Note that there is no difference between uppercase and 
lowercase letters. Also, kerning has been enabled for this font.

--------------------------------------------------

LEGAL MUMBO JUMBO

This font is not officially licensed and is not intended to infringe on 
any copyright. This font is freeware; it may be distributed freely, but 
PLEASE distribute all files included in the ZIP archive. This font is
NOT to be sold or used for financial gain. Help keep it free and
available!